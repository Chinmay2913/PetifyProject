export const homeCarouselData=[
    {
        image:"https://pawsindia.com/cdn/shop/files/Tshirt_Web_GIF_1_1920x.gif?v=1723557438",
        path:"/cats/clothing/foods"
    },
    {
        image:"https://cdn.shopify.com/s/files/1/0565/8021/0861/files/1July_Henlo_Main-min_9cb567d1-4e7a-4da1-94e9-41c0abda4f2c.png?v=1723790179",
        path:"/cats/clothing/foods"
    },
    {
        image:"https://cdn.shopify.com/s/files/1/0565/8021/0861/files/weekend_mania_Sale_web__gen-min.png?v=1723788818",
        path:"/cats/clothing/foods"
    },
    {
        image:"https://pawsindia.com/cdn/shop/files/Pee-_-Poo-Absorbant-Tissues-Web_1920x.jpg?v=1715806175",
        path:"/cats/clothing/foods"
    }

]


